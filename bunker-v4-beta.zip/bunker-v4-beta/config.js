window._config = {
	"apps": [
		"yt-cl",
		"comms",
		"prxyz",
		"info",
		"mpviewer",
		"conn_stats",
		"hacker-news-tile",
		"sample-games"
	]
}