window.apps["prxyz"] = {};
window.apps["prxyz"]["tile"] = `<div class="box_widget">
	<div>
		<h3>Pro&zwj;xies</h3>
	</div>
	<div>
		<ul class="list">
			<li>the long (4 days) awaited feature is here:</li>
			<li>open node:
				<select class="btn-inline minize" id="prxyz_select">
					<option>none</option>
					<option>1</option>
					<option>2</option>
					<option>3</option>
					<option>4</option>
					<option>5</option>
					<option>6</option>
					<option>7</option>
					<option>8</option>
					<option>9</option>
					<option>10</option>
					<option>11</option>
					<option>12</option>
					<option>13</option>
					<option>14</option>
				</select>
			</li>
		</ul>
	</div>
	<script src="apps/prxyz/tile.js"></script>
</div>`;